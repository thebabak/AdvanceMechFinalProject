function test1forAll_FourPatches
    %% Optimal placement for four patches
    lb = zeros(1, 8); % Lower bounds on individual design variables (8 variables: x1, x2, ..., x8)
    ub = 50 .* ones(1, 8); % Upper bounds on individual design variables
    fitnessfcn = @objF4; % Use the fourth objective function for four patches
    nvars = 8; % Number of design variables (start and end positions for 4 patches)
    Lp = 5; % Length of each piezopatch (5m = 1/10th of the beam length)
    
    % Equality constraints: Each patch has a fixed length
    Aeq = [-1, 1, 0, 0, 0, 0, 0, 0; ...
           0, 0, -1, 1, 0, 0, 0, 0; ...
           0, 0, 0, 0, -1, 1, 0, 0; ...
           0, 0, 0, 0, 0, 0, -1, 1];
    beq = [Lp; Lp; Lp; Lp]; % Each patch has length Lp

    % Inequality constraints: Prevent overlap between patches
    A = [1, -1, 0, 0, 0, 0, 0, 0; ...
         0, 1, -1, 0, 0, 0, 0, 0; ...
         0, 0, 1, -1, 0, 0, 0, 0; ...
         0, 0, 0, 1, -1, 0, 0, 0; ...
         0, 0, 0, 0, 1, -1, 0, 0; ...
         0, 0, 0, 0, 0, 1, -1, 0; ...
         0, 0, 0, 0, 0, 0, 1, -1];
    b = zeros(7, 1); % Inequalities prevent overlap

    % Options for the genetic algorithm
    opts = gaoptimset('PlotFcn', {@gaplotbestf, @gaplotstopping}, ...
                      'Generations', 200, 'TolFun', 1e-6, 'TolCon', 1e-6);

    % Solve the optimization problem
    [x4, fval4, exitflag4, output4] = ga(fitnessfcn, nvars, A, b, Aeq, beq, lb, ub, [], opts);
    disp('Optimal placement for four patches:');
    disp([x4, fval4]');

    %% Plot results for four patches as bar plot
    figure;
    bar(x4, 0.3, 'FaceColor', 'cyan');
    title('Optimal Placement for Four Patches');
    xlabel('Patch Boundaries');
    ylabel('Position (m)');
    xlim([0.5, 8.5]);
    xticks(1:8);
    xticklabels({'x_1', 'x_2', 'x_3', 'x_4', 'x_5', 'x_6', 'x_7', 'x_8'});

    %% Visualize the placement of patches on the beam
    figure;
    hold on;
    beamLength = 50; % Total length of the beam
    patchColors = lines(4); % Use distinct colors for each patch
    yOffset = 1; % Vertical offset for visual clarity
    
    % Draw the beam as a horizontal line
    plot([0, beamLength], [0, 0], 'k-', 'LineWidth', 2); % Beam line
    
    % Draw each patch as a rectangle
    for i = 1:4
        xStart = x4(2*i-1); % Start of patch i
        xEnd = x4(2*i); % End of patch i
        rectangle('Position', [xStart, -yOffset, xEnd - xStart, 2 * yOffset], ...
                  'FaceColor', patchColors(i, :), 'EdgeColor', 'k');
    end
    
    % Add labels and formatting
    title('Placement of Patches on the Beam');
    xlabel('Beam Length (m)');
    ylabel('Placement');
    ylim([-yOffset*1.5, yOffset*1.5]);
    xlim([0, beamLength]);
    legend({'Beam', 'Patch 1', 'Patch 2', 'Patch 3', 'Patch 4'}, 'Location', 'northeast');
    hold off;

    %% Create Continuous-Time State-Space Model
    % Define system parameters
    nModes = 4; % Number of vibration modes
    omega = [10, 30, 50, 80]; % Natural frequencies (rad/s)
    zeta = [0.01, 0.01, 0.01, 0.01]; % Damping ratios
    B_p = [1, 0.8, 0.6, 0.4]; % Actuation coupling coefficients
    C_p = [1, 0.9, 0.7, 0.5]; % Sensing coupling coefficients

    % Generate state-space matrices
    [A, B, C, D] = beamPiezoStateSpace(nModes, omega, zeta, B_p, C_p);

    % Display the state-space matrices
    disp('State-space matrices:');
    disp('A ='); disp(A);
    disp('B ='); disp(B);
    disp('C ='); disp(C);
    disp('D ='); disp(D);

    % Create the state-space system
    sys = ss(A, B, C, D);

    % Plot the system's step response
    figure;
    step(sys);
    title('Step Response of the Beam-Piezoelectric System');
end

%% Objective Function for Four Patches
function f = objF4(X)
    try
        %% Beam properties
        rho_b = 2710; % Density, kg/m^3
        E_b = 71e9; % Young's modulus, Pa
        v_b = 0.3; % Poisson's ratio, dimensionless
        t_b = 5e-3; % Thickness, m
        L_b = 50; % Length of the beam, m
        b = 0.01; % Width, m
        J_b = b * t_b^3 / 12; % Area Moment of Inertia
        A_b = b * t_b; % Cross-sectional area of the beam
        zeta = diag([0.01, 0.01, 0.01, 0.01]); % Damping ratio, dimensionless

        %% Piezoelectric patch properties
        rho = 7500; % Density, kg/m^3
        E = 126e9; % Young's modulus, Pa
        d31 = -6.5; % Piezoelectric constant, m/V
        h31 = 1.5e-8; % Piezoelectric constant, V/m
        t = 4e-5; % Thickness, m

        %% Derived constants
        Ka = b * ((t_b + t) / 2) * d31 * E;

        % Avoid division by zero by checking validity of X(2:2:end) - X(1:2:end)
        if any((X(2:2:end) - X(1:2:end)) <= 0)
            f = 1e6; % Penalty for invalid configuration
            return;
        end

        Ks1 = -t * h31 * ((t_b + t) / 2) ./ (X(2:2:end) - X(1:2:end));

        %% Natural frequencies for first 4 modes
        wj = (pi / L_b)^2 * sqrt(E_b * J_b / (rho_b * A_b));
        W = wj .* (diag([1, 2^2, 3^2, 4^2]));

        %% Mode shape derivative differences for all elements
        Udiff = zeros(4, 4); % Each row corresponds to one mode
        for i = 1:4
            Udiff(i, :) = sqrt(2 / (rho_b * L_b * A_b)) * (i * pi / L_b) * ...
                          (cos((i * pi * X(2:2:end)) / L_b) - cos((i * pi * X(1:2:end)) / L_b));
        end

        %% Open loop matrices
        B_ = Ka .* Udiff;
        C_ = Ks1 .* Udiff;
        A = vertcat([zeros(4), eye(4)], [-W * W, -2 * zeta * W]);
        Q = vertcat([W * W, zeros(4)], [zeros(4), eye(4)]);

        %% Closed loop matrices
        G = 0.4;
        Ac = double(vertcat([zeros(4), eye(4)], [-W * W, B_ * G * C_ - 2 .* zeta * W]));

        %% Initial conditions
        n0 = [0, 0, 0, 0]; 
        n0_d = [0.2, 0.4, 0.6, 0.8];
        n = [n0, n0_d];
        P = lyap(double(Ac)', -double(Q)); % Lyapunov equation
        f = max(-double(n * P * n'), 0); % Objective function
    catch
        % If an error occurs, assign a large penalty value
        f = 1e6; % Penalty for invalid computation
    end
end

%% Continuous-Time State-Space Model Function
function [A, B, C, D] = beamPiezoStateSpace(nModes, omega, zeta, B_p, C_p)
    % Inputs:
    % nModes - Number of vibration modes to consider
    % omega - Natural frequencies (vector of size nModes)
    % zeta - Damping ratios (vector of size nModes)
    % B_p - Actuation matrix (vector of size nModes, one for each mode)
    % C_p - Sensing matrix (vector of size nModes, one for each mode)
    %
    % Outputs:
    % A, B, C, D - State-space matrices for the continuous-time system

    % Initialize state-space matrices
    A = zeros(2 * nModes); % State matrix (2n x 2n)
    B = zeros(2 * nModes, 1); % Input matrix (2n x 1)
    C = zeros(1, 2 * nModes); % Output matrix (1 x 2n)
    D = 0; % Direct feedthrough (scalar)

    % Fill the A matrix
    for i = 1:nModes
        % Index for state variables (displacement and velocity)
        idx = 2 * (i - 1) + 1;
        A(idx, idx + 1) = 1; % Displacement to velocity mapping
        A(idx + 1, idx) = -omega(i)^2; % Dynamics of mode i
        A(idx + 1, idx + 1) = -2 * zeta(i) * omega(i); % Damping
    end

    % Fill the B matrix (actuation input)
    for i = 1:nModes
        idx = 2 * (i - 1) + 2; % Velocity state
        B(idx) = B_p(i); % Actuation coupling for mode i
    end

    % Fill the C matrix (output)
    for i = 1:nModes
        idx = 2 * (i - 1) + 1; % Displacement state
        C(1, idx) = C_p(i); % Sensing coupling for mode i
    end
end