function userDefinedPiezo
    %% Beam properties (Updated)
    rho_b = 2710; % density, kg/m^3
    E_b = 71e9; % Young's modulus, Pa
    v_b = 0.3; % Poisson's ratio, dimensionless
    t_b = 5e-3; % thickness, m
    L_b = 0.5; % length, m
    b = 0.01; % width, m
    J_b = b * t_b^3 / 12; % Area Moment of Inertia
    A_b = b * t_b; % Cross-sectional area of the beam
    zeta = diag([0.01, 0.01, 0.01, 0.01]); % Damping ratio, dimensionless

    %% Piezoelectric patch properties (Updated)
    rho = 7500; % density, kg/m^3
    E = 126e9; % Young's modulus, Pa
    d31 = -6.5; % Piezoelectric constant, m/V
    h31 = 1.5e-8; % Piezoelectric constant, V/m
    t = 4e-5; % thickness, m

    %% Ask user for number of patches
    numPatches = input('Enter the number of piezoelectric patches: ');
    if numPatches < 1
        disp('The number of patches must be at least 1.');
        return;
    end

    %% Ask user for the positions of the patches
    positions = zeros(1, 2 * numPatches); % Each patch has a start and end position
    for i = 1:numPatches
        fprintf('Enter the start and end positions of patch %d (in meters, between 0 and %.2f):\n', i, L_b);
        while true
            positions(2*i-1) = input(sprintf('  Start position of patch %d: ', i));
            positions(2*i) = input(sprintf('  End position of patch %d: ', i));
            if positions(2*i-1) >= 0 && positions(2*i) <= L_b && positions(2*i-1) < positions(2*i)
                break;
            else
                disp('Invalid positions. Ensure the start is less than the end and within the beam length.');
            end
        end
    end

    %% Derived constants
    Ka = b * ((t_b + t) / 2) * d31 * E;
    Ks = zeros(1, numPatches);
    for i = 1:numPatches
        Ks(i) = -t * h31 * ((t_b + t) / 2) / (positions(2*i) - positions(2*i-1));
    end

    %% Natural frequencies for first 4 modes (Updated)
    wj = (pi / L_b)^2 * sqrt(E_b * J_b / (rho_b * A_b));
    W = wj .* (diag([1, 2^2, 3^2, 4^2]));

    %% Mode shape derivative differences for all elements
    Udiff = zeros(4, numPatches);
    for i = 1:numPatches
        U1 = (sqrt(2 / (rho_b * L_b * A_b))) * (1 * pi / L_b) * ...
             (cos((1 * pi * positions(2*i)) / L_b) - cos((1 * pi * positions(2*i-1)) / L_b));
        U2 = (sqrt(2 / (rho_b * L_b * A_b))) * (2 * pi / L_b) * ...
             (cos((2 * pi * positions(2*i)) / L_b) - cos((2 * pi * positions(2*i-1)) / L_b));
        U3 = (sqrt(2 / (rho_b * L_b * A_b))) * (3 * pi / L_b) * ...
             (cos((3 * pi * positions(2*i)) / L_b) - cos((3 * pi * positions(2*i-1)) / L_b));
        U4 = (sqrt(2 / (rho_b * L_b * A_b))) * (4 * pi / L_b) * ...
             (cos((4 * pi * positions(2*i)) / L_b) - cos((4 * pi * positions(2*i-1)) / L_b));
        Udiff(:, i) = [U1; U2; U3; U4];
    end

    %% Open loop matrices
    B_ = Ka .* Udiff;
    C_ = zeros(numPatches, 4);
    for i = 1:numPatches
        C_(i, :) = Ks(i) * Udiff(:, i)';
    end
    A = vertcat([zeros(4), eye(4)], [-W*W, -2*zeta*W]);
    B = [zeros(4, numPatches); B_];
    C = [C_, zeros(numPatches, 4)];
    Q = vertcat([W*W, zeros(4)], [zeros(4), eye(4)]);

    %% Close loop matrices
    G = eye(numPatches) * 0.4; % Control gain (diagonal for simplicity)
    Ac = double(vertcat([zeros(4), eye(4)], [-W*W, B_*G*C_ - 2.*zeta*W]));

    %% Initial conditions
    n0 = [1, 0, 0, 0]; % Initial displacement (set the first mode to 1 as an example)
    n0_d = [0, 0, 0, 0]; % Initial velocities
    n = [n0, n0_d];

    %% Calculate system response
    P = lyap(double(Ac)', -double(Q)); % Solve Lyapunov equation
    response = diag(P); % Extract the diagonal terms (energy contribution of each mode)

    %% Plot the response
    figure;
    subplot(2, 1, 1);
    bar(reshape(positions, 2, numPatches)', 0.3, 'FaceColor', 'cyan');
    title('Piezoelectric Patch Positions');
    xlabel('Patch Index');
    ylabel('Position (m)');
    xticks(1:numPatches);
    xticklabels(arrayfun(@(x) sprintf('Patch %d', x), 1:numPatches, 'UniformOutput', false));
    grid on;

    subplot(2, 1, 2);
    plot(1:4, response(1:4), 'LineWidth', 2, 'Marker', 'o', 'Color', 'b');
    title('System Response (Amplitude)');
    xlabel('Mode Number');
    ylabel('Response Amplitude');
    xticks(1:4);
    grid on;

    %% Display results
    disp('System response (mode energy contributions):');
    disp(response(1:4));
end