function f = objF2(X)
rho_b = 1190; 
E_b = 3.1028e9; 
v_b = 0.3; 
t_b = 1.6e-3; 
L_b = 0.5; 
b = 0.01; 
J_b = b*t_b^3/12; 
A_b = b*t_b; 
zeta = diag([0.01,0.01,0.01,0.01]); 

rho = 1800; 
E = 2e9; 
d31 = 2.3e-11; 
h31 = 4.32e8; 
v = 0.3; 
t = 4e-5; 

Ka = b*((t_b+t)/2)*d31*E;
Ks1 = -t*h31*((t_b+t)/2)/(X(2)-X(1));
Ks2 = -t*h31*((t_b+t)/2)/(X(4)-X(3));

wj = (pi/L_b)^2*sqrt(E_b*J_b/(rho_b*A_b));
W = wj.*(diag([1,2^2,3^2,4^2]));

U1diff21 = (sqrt(2/(rho_b*L_b*A_b)))*(1*pi/L_b)*(cos((1*pi*X(2))/L_b)-cos((1*pi*X(1))/L_b));
U2diff21 = (sqrt(2/(rho_b*L_b*A_b)))*(2*pi/L_b)*(cos((2*pi*X(2))/L_b)-cos((2*pi*X(1))/L_b));
U3diff21 = (sqrt(2/(rho_b*L_b*A_b)))*(3*pi/L_b)*(cos((3*pi*X(2))/L_b)-cos((3*pi*X(1))/L_b));
U4diff21 = (sqrt(2/(rho_b*L_b*A_b)))*(4*pi/L_b)*(cos((4*pi*X(2))/L_b)-cos((4*pi*X(1))/L_b));

U1diff43 = (sqrt(2/(rho_b*L_b*A_b)))*(1*pi/L_b)*(cos((1*pi*X(4))/L_b)-cos((1*pi*X(3))/L_b));
U2diff43 = (sqrt(2/(rho_b*L_b*A_b)))*(2*pi/L_b)*(cos((2*pi*X(4))/L_b)-cos((2*pi*X(3))/L_b));
U3diff43 = (sqrt(2/(rho_b*L_b*A_b)))*(3*pi/L_b)*(cos((3*pi*X(4))/L_b)-cos((3*pi*X(3))/L_b));
U4diff43 = (sqrt(2/(rho_b*L_b*A_b)))*(4*pi/L_b)*(cos((4*pi*X(4))/L_b)-cos((4*pi*X(3))/L_b));

B_ = Ka.*[U1diff21,U1diff43;...
    U2diff21,U2diff43;...
    U3diff21,U3diff43;...
    U4diff21,U4diff43];

C_ = [Ks1.*[U1diff21,U2diff21,U3diff21,U4diff21];...
    Ks2.*[U1diff43,U2diff43,U3diff43,U4diff43]];
    
A = vertcat([zeros(4),eye(4)],[-W*W,-2*zeta*W]);
B = [zeros(4,2);B_];
C = [C_,zeros(2,4)];
Q = vertcat([W*W,zeros(4)],[zeros(4),eye(4)]);

G = [.4,0.4;0,0.4];
Ac = double(vertcat([zeros(4),eye(4)],[-W*W,B_*G*C_-2.*zeta*W]));

n0 = [0,0,0,0]; n0_d = [0.2,0.4,0.6,0.8]; n = [n0,n0_d];
P = lyap(double(Ac)',-double(Q)); 
f = max(-double(n*P*n'),0);
end