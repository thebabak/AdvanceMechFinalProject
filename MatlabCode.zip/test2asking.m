clc
clear all
close all
function userDefinedPiezo
    %% Beam properties
    rho_b = 1190; % density, kg/^3
    E_b = 3.1028e9; % Young's modulus, Pa
    v_b = 0.3; % Poisson's ratio, dimensionless
    t_b = 1.6e-3; % thickness, m
    L_b = 0.5; % length, m
    b = 0.01; % width, m
    J_b = b*t_b^3/12; % Area Moment of Inertia
    A_b = b*t_b; % Cross-sectional area of the beam
    zeta = diag([0.01, 0.01, 0.01, 0.01]); % Damping ratio, dimensionless

    %% Piezoelectric patch properties
    rho = 1800; % density, kg/^3
    E = 2e9; % Young's modulus, Pa
    d31 = 2.3e-11; % Piezoelectric constant, m/V
    h31 = 4.32e8; % Piezoelectric constant, V/m
    t = 4e-5; % thickness, m

    %% Ask user for number of patches
    numPatches = input('Enter the number of piezoelectric patches: ');
    if numPatches < 1
        disp('The number of patches must be at least 1.');
        return;
    end

    %% Ask user for the positions of the patches
    positions = zeros(1, 2 * numPatches); % Each patch has a start and end position
    for i = 1:numPatches
        fprintf('Enter the start and end positions of patch %d (in meters, between 0 and %.2f):\n', i, L_b);
        while true
            positions(2*i-1) = input(sprintf('  Start position of patch %d: ', i));
            positions(2*i) = input(sprintf('  End position of patch %d: ', i));
            if positions(2*i-1) >= 0 && positions(2*i) <= L_b && positions(2*i-1) < positions(2*i)
                break;
            else
                disp('Invalid positions. Ensure the start is less than the end and within the beam length.');
            end
        end
    end

    %% Derived constants
    Ka = b * ((t_b + t) / 2) * d31 * E;
    Ks = zeros(1, numPatches);
    for i = 1:numPatches
        Ks(i) = -t * h31 * ((t_b + t) / 2) / (positions(2*i) - positions(2*i-1));
    end

    %% Natural frequencies for first 4 modes
    wj = (pi / L_b)^2 * sqrt(E_b * J_b / (rho_b * A_b));
    W = wj .* (diag([1, 2^2, 3^2, 4^2]));

    %% Mode shape derivative differences for all elements
    Udiff = zeros(4, numPatches);
    for i = 1:numPatches
        U1 = (sqrt(2 / (rho_b * L_b * A_b))) * (1 * pi / L_b) * ...
             (cos((1 * pi * positions(2*i)) / L_b) - cos((1 * pi * positions(2*i-1)) / L_b));
        U2 = (sqrt(2 / (rho_b * L_b * A_b))) * (2 * pi / L_b) * ...
             (cos((2 * pi * positions(2*i)) / L_b) - cos((2 * pi * positions(2*i-1)) / L_b));
        U3 = (sqrt(2 / (rho_b * L_b * A_b))) * (3 * pi / L_b) * ...
             (cos((3 * pi * positions(2*i)) / L_b) - cos((3 * pi * positions(2*i-1)) / L_b));
        U4 = (sqrt(2 / (rho_b * L_b * A_b))) * (4 * pi / L_b) * ...
             (cos((4 * pi * positions(2*i)) / L_b) - cos((4 * pi * positions(2*i-1)) / L_b));
        Udiff(:, i) = [U1; U2; U3; U4];
    end

    %% Open loop matrices
    B_ = Ka .* Udiff;
    C_ = zeros(numPatches, 4);
    for i = 1:numPatches
        C_(i, :) = Ks(i) * Udiff(:, i)';
    end
    A = vertcat([zeros(4), eye(4)], [-W*W, -2*zeta*W]);
    B = [zeros(4, numPatches); B_];
    C = [C_, zeros(numPatches, 4)];
    Q = vertcat([W*W, zeros(4)], [zeros(4), eye(4)]);

    %% Close loop matrices
    G = eye(numPatches) * 0.4; % Control gain (assume diagonal for simplicity)
    Ac = double(vertcat([zeros(4), eye(4)], [-W*W, B_*G*C_ - 2.*zeta*W]));

    %% Initial conditions
    n0 = [0, 0, 0, 0]; % Initial displacement
    n0_d = [0.2, 0.4, 0.6, 0.8]; % Initial velocities
    n = [n0, n0_d];

    %% Calculate system response
    P = lyap(double(Ac)', -double(Q)); % Solve Lyapunov equation
    response = -double(n * P * n'); % Compute response

    %% Plot the response
    figure;
    subplot(2, 1, 1);
    bar(positions, 0.3, 'FaceColor', 'cyan');
    title('Piezoelectric Patch Positions');
    xlabel('Patch Boundaries');
    ylabel('Position (m)');
    xticks(1:length(positions));
    grid on;

    subplot(2, 1, 2);
    plot(response, 'LineWidth', 2);
    title('System Response');
    xlabel('Mode Number');
    ylabel('Response Amplitude');
    grid on;

    %% Display results
    disp('System response:');
    disp(response);
end